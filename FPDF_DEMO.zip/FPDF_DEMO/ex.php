<?php
require('mc_table.php');
$conn = mysql_connect("localhost","root","root123");
if($conn)
{
        mysql_select_db("studentdb",$conn);
}


$pdf = new PDF_MC_Table('L','mm','A4');
//first Page
$pdf->AddPage();
$pdfWidth = $pdf->getWidth1();
$pdfHeight = $pdf->getHeight1();
$pdf->Image("/var/www/html/FPDF_DEMO/mysql_table/images/vertical.jpg",$pdfWidth/2,27,3,$pdfHeight- 55); //vertical image
$pdf->Image("/var/www/html/FPDF_DEMO/mysql_table/images/horizontal.jpg",20,$pdfHeight/2,($pdfWidth/2)-19,3); //Horizontal image
$pdf->SetFont('Arial','B',35);
$pdf->Text(40,$pdfHeight/2 - 4,"eScan Reports");
$pdf->SetFont('Arial','',18);
$pdf->Text(($pdfWidth/2)+10,$pdfHeight/2 + 30,"Generated On :");
$date = date("d/m/Y");
$time = date("h:i:s A");
$dateTime = $date." ".$time;
$pdf->Text(($pdfWidth/2)+58,$pdfHeight/2 + 30,$dateTime);
//Table pages
$pdf->AddPage();
$pdf->SetFont('Arial','',14);
//Table with 20 rows and 4 columns
$pdf->SetWidths(array(10,30,30,60));
srand(microtime()*1000000);

$sql = "select * from samplePdfData";
$result = mysql_query($sql,$conn);
if($result)
{
	/*
	for($i = 0; $i < 4; $i++)
	{
	
		$row = array("aaaaaaaaaa","bbbbbbbbbbb");
		$pdf->Row($row);
	}
	*/
	$rowArray = array();
	while($row = mysql_fetch_assoc($result))
	{
		$rowArray[] = $row['ID'];
		$rowArray[] = $row['Company'];
		$rowArray[] = $row['mobile'];
		$rowArray[] = $row['col4'];
		$pdf->Row($rowArray);
		$rowArray = array();
	}

}
$pdf->Output();
?>
