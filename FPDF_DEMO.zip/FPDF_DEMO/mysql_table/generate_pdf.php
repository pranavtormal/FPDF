<?php
require('mysql_table.php');
class PDF extends PDF_MySQL_Table
{
	//Header
	function Header()
	{
		//Title
		$this->SetFont('Arial','',18);
		$this->Image("/var/www/html/FPDF_DEMO/mysql_table/images/management_console_r1_c1.jpg",0,0,300,25);
		$this->Image("/var/www/html/FPDF_DEMO/mysql_table/images/management_console_r1_c3.jpg",300,0,125,25);
		$this->Cell(0,6,'eScan VAPT',0,1,'C');
		$this->Ln(20);
		//Ensure table header is output
		parent::Header();
	}
	//Footer
	function Footer()
	{
    		// Position at 1.5 cm from bottom
    		$this->SetY(-15);
    		// Arial italic 8
    		$this->SetFont('Arial','',8);
		$this->Image("/var/www/html/FPDF_DEMO/mysql_table/images/management_console_r1_c1.jpg",0,$this->GetY()-10,$this->w,25);
                //$this->Image("/opt/MicroWorld/var/www/htdocs/suhas/FPDF_DEMO/mysql_table/images/management_console_r1_c3.jpg",300,$this->GetY()-10,125,25);
   		 // Page number
    		//$this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
	}
	
	
}

//Connect to database
$conn = mysql_connect('localhost', 'root','root123');
if (!$conn) {
    die('Could not connect: ' . mysql_error());
}
mysql_select_db("studentdb", $conn) or die('Could not select database.');

$pdf=new PDF('L','mm','A3');//array(height,width) 
//First Page
$pdf->AddPage();
$pdfWidth = $pdf->getWidth1();
$pdfHeight = $pdf->getHeight1();
$pdf->Image("/var/www/html/FPDF_DEMO/mysql_table/images/vertical.jpg",$pdfWidth-200,27,3,$pdfHeight- 55); //vertical image
$pdf->Image("/var/www/html/FPDF_DEMO/mysql_table/images/horizontal.jpg",20,$pdfHeight/2,$pdfWidth-220,3); //Horizontal image
$pdf->SetFont('Arial','B',35);
$pdf->Text(40,$pdfHeight/2 - 4,"eScan Reports");
$pdf->SetFont('Arial','',18);
$pdf->Text($pdfWidth-190,$pdfHeight/2 + 30,"Generated On :");
$date = date("d/m/Y");
$time = date("h:i:s A");
$dateTime = $date." ".$time;
$pdf->Text($pdfWidth-135,$pdfHeight/2 + 30,$dateTime);
//new page
$pdf->AddPage();
//First table: put all columns automatically
/*
$pdf->Table('select * from CloudUserList');
$pdf->AddPage();
$pdf->AddPage();
*/
/*
//Second table: specify 3 columns
$pdf->AddCol('ID',10,'','L');
$pdf->AddCol('templateCreatedby',80,'','L');
$pdf->AddCol('templateName',40,'','L');
$pdf->AddCol('importance',40,'','L');
$pdf->AddCol('Description',55,'','L');
$pdf->AddCol('AssetType',30,'','L');
$pdf->AddCol('IncludeAssets',80,'','L');
$pdf->AddCol('SchedulerType',30,'','L');
$pdf->AddCol('reportGenAtTime',35,'','L');
*/
//for alternate color with header
/*
$prop=array('HeaderColor'=>array(177,206,100),
			'color1'=>array(255,255,255),
			'color2'=>array(222,239,198),
			'padding'=>2);
*/
$pdf->Table('select ID,Company,mobile,col4 from samplePdfData','');
//$filename = "/opt/MicroWorld/var/www/htdocs/suhas/FPDF_DEMO/mysql_table/test.pdf";

$pdf->Output();
mysql_close($conn);
?>
